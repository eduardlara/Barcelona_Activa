package com.example.demo.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.dao.StudentDAO;
import com.example.demo.dao.UniversityDAO;
import com.example.demo.entity.Student;
import com.example.demo.entity.University;


@RestController 
@RequestMapping("/") 
public class ControllerRest {

	@Autowired 
	private UniversityDAO universityDAO;
	@Autowired 
	private StudentDAO studentDAO;

	
		@PostMapping("/creauni") 
		public ResponseEntity<String> crearUniversidad() {
			
			University university = new University("UPC");

		    List<Student> lineas = new ArrayList<>();
		    Student pepe = new Student("Jose",university);
		    Student jose = new Student("Jesus",university);
		    Student maria = new Student("Maria",university);
		    
		    lineas.add(pepe);lineas.add(jose);lineas.add(maria);
		    university.setStudents(lineas);
			University uni = universityDAO.save(university);			
			return ResponseEntity.ok("Universidad creada");
		}
	
		@GetMapping("/universidades")
		public ResponseEntity<List<University>> getTiendas() {
			List<University> lista = universityDAO.findAll();
			return ResponseEntity.ok(lista);
		}
		@Transactional
		@PostMapping("/borrar/{id}") 
		public ResponseEntity<String> crearProductoTienda( @PathVariable("id") Long id) {
			
			Optional<University> uni = universityDAO.findById(id);
			studentDAO.deleteByUniversity(uni.get());
			return ResponseEntity.ok("borrado alumnos universidad "+id);
		}

}

