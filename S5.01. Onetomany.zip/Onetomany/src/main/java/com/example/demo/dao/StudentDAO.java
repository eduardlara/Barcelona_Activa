package com.example.demo.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.demo.entity.Student;
import com.example.demo.entity.University;


public interface StudentDAO extends JpaRepository<Student,Long> {
	//List<Producto> findProductoByshopid(Long shopid);
	//List<Student> findAllByShopid(int shopid);
	void deleteByUniversity(University uni);
	//void deleteByUniversityid(int uni_id);
	
	
}
